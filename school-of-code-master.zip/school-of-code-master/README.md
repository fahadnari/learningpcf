# School of Code

![alt tag](https://adammarxsmind.files.wordpress.com/2015/03/2003_the_school_of_rock_wallpaper_002.jpg)
A place for non coders to learn about coding 

For the course outline go to our [wiki](https://github.com/springernature/school_of_code/wiki)

The course notes and tasks are inside the session folder
