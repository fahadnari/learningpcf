# School of Code Api

An example of a Service that displays blogs

Routes:

GET:

- / gives you a list of posts